//
//  CounterViewModel.swift
//  MVVM
//
//  Created by Aarsh  Patel on 12/02/24.
//

import Foundation
import SwiftUI

class CounterViewModel: ObservableObject {
    
    @Published private var counter: Counter = Counter()
    
    var value: Int {
        counter.value
    }
    
    var premium: Bool {
        counter.isPremium
    }
    
    func increment() {
        counter.Increment()
    }
    
}
