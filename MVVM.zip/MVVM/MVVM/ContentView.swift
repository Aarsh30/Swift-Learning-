//
//  ContentView.swift
//  MVVM
//
//  Created by Aarsh  Patel on 12/02/24.
//

import SwiftUI

struct ContentView: View {
    @ObservedObject private var counterVM = CounterViewModel()
    
    init() {
        counterVM = CounterViewModel()
    }
    var body: some View {
       
        VStack {
            Text(counterVM.premium ? "Premium" : "")
                .font(.largeTitle)
                .fontWeight(.bold)
                .foregroundColor(.white)
                .frame(width: 200, height: 50, alignment: .center)
                .background(.gray)
                .cornerRadius(10)
            
            Text("\(counterVM.value)")
                .font(.title)
            
            Button("Increment") {
                // Increment the count
                self.counterVM.increment()
            }
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
