//
//  MVVMApp.swift
//  MVVM
//
//  Created by Aarsh  Patel on 12/02/24.
//

import SwiftUI

@main
struct MVVMApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
