//
//  Counter.swift
//  MVVM
//
//  Created by Aarsh  Patel on 12/02/24.
//

import Foundation

struct Counter{
    
    var value: Int = 0
    var isPremium: Bool = false
    mutating func Increment(){
        value += 1
        
        
        //business logic
        if value % 3 == 0{
            isPremium = true
          //  print("Premium")
        }
        else
        {
            isPremium = false
           // print("Not Premium")
        }
    }
    

}
