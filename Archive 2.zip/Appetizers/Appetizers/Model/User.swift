//
//  User.swift
//  Appetizers
//
//  Created by Aarsh  Patel on 01/02/24.
//

import Foundation

struct User: Codable{

     var firstName = ""
    var lastName = ""
    var email = ""
    var birthday = Date()
    var extraNapkins = false
    var frequentrefill = false
    
}
