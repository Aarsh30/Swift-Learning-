//
//  ActivityView.swift
//  Threads
//
//  Created by Aarsh  Patel on 05/02/24.
//

import SwiftUI

struct ActivityView: View {
    var body: some View {
        Text("Hello Activity View")
    }
}

#Preview {
    ActivityView()
}
