//
//  SwiftUI_WeatherApp.swift
//  SwiftUI-Weather
//
//  Created by Aarsh  Patel on 29/01/24.
//

import SwiftUI

@main
struct SwiftUI_WeatherApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
