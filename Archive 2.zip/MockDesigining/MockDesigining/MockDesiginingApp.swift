//
//  MockDesiginingApp.swift
//  MockDesigining
//
//  Created by Aarsh  Patel on 09/02/24.
//

import SwiftUI

@main
struct MockDesiginingApp: App {
    var body: some Scene {
        WindowGroup {
           
                ContentView()
            
           
        }
    }
}
