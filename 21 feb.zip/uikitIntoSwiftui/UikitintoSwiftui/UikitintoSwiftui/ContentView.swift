//
//  ContentView.swift
//  UikitintoSwiftui
//
//  Created by Aarsh  Patel on 21/02/24.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        VStack {
//            Image(systemName: "globe")
//                .imageScale(.large)
//                .foregroundStyle(.tint)
            UILabelView(text: "uikit into swiftui")
               
           
        }
        .padding()
    }
}

#Preview {
    ContentView()
}
