//
//  UikitintoSwiftuiApp.swift
//  UikitintoSwiftui
//
//  Created by Aarsh  Patel on 21/02/24.
//

import SwiftUI

@main
struct UikitintoSwiftuiApp: App {
    var body: some Scene {
        WindowGroup {
            ColorPickerView()
        }
    }
}
