//
//  Apple_FrameworksApp.swift
//  Apple-Frameworks
//
//  Created by Aarsh  Patel on 29/01/24.
//

import SwiftUI

@main
struct Apple_FrameworksApp: App {
    var body: some Scene {
        WindowGroup {
            FrameworkGridView()
        }
    }
}
