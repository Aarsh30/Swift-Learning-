//
//  CryptoAsyncAwaitApp.swift
//  CryptoAsyncAwait
//
//  Created by Stephan Dowless on 1/5/23.
//

import SwiftUI

@main
struct CryptoAsyncAwaitApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
